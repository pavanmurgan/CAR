package com.resourcetrackingmgmt.service;

import com.resourcetrackingmgmt.model.Groups;
import com.resourcetrackingmgmt.model.TaskList;
import com.resourcetrackingmgmt.model.Users;

public interface ResourceTrackingService {
	public void userRegistration(Users users);
	public void createGroup(Groups groups);
	public void createTaskGroup(TaskList taskList);
	public void approveUser(Users users, String role);
}
