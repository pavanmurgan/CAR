package com.resourcetrackingmgmt.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T_REQUEST_DETAILS")
public class Requests {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "requestId")
	private int requestId;

	@Column(name = "typeOfRequest")
	private String typeOfRequest;

	@Column(name = "userId")
	private int userId;

	@Column(name = "leadId")
	private int leadId;

	@Column(name = "leaveStartDate")
	private Date leaveStartDate;

	@Column(name = "leaveEndDate")
	private Date leaveEndDate;

	@Column(name = "taskId")
	private int taskId;

	@Column(name = "extenstionDate")
	private Date extenstionDate;

	@Column(name = "comments")
	private String comments;

	@Column(name = "submittedOn")
	private Date submittedOn;

	@Column(name = "status")
	private String status;

	/**
	 * @return the requestId
	 */
	public int getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the typeOfRequest
	 */
	public String getTypeOfRequest() {
		return typeOfRequest;
	}

	/**
	 * @param typeOfRequest the typeOfRequest to set
	 */
	public void setTypeOfRequest(String typeOfRequest) {
		this.typeOfRequest = typeOfRequest;
	}

	/**
	 * @return the userId
	 */
	public int getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}

	/**
	 * @return the leadId
	 */
	public int getLeadId() {
		return leadId;
	}

	/**
	 * @param leadId the leadId to set
	 */
	public void setLeadId(int leadId) {
		this.leadId = leadId;
	}

	/**
	 * @return the leaveStartDate
	 */
	public Date getLeaveStartDate() {
		return leaveStartDate;
	}

	/**
	 * @param leaveStartDate the leaveStartDate to set
	 */
	public void setLeaveStartDate(Date leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}

	/**
	 * @return the leaveEndDate
	 */
	public Date getLeaveEndDate() {
		return leaveEndDate;
	}

	/**
	 * @param leaveEndDate the leaveEndDate to set
	 */
	public void setLeaveEndDate(Date leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}

	/**
	 * @return the taskId
	 */
	public int getTaskId() {
		return taskId;
	}

	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return the extenstionDate
	 */
	public Date getExtenstionDate() {
		return extenstionDate;
	}

	/**
	 * @param extenstionDate the extenstionDate to set
	 */
	public void setExtenstionDate(Date extenstionDate) {
		this.extenstionDate = extenstionDate;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the submittedOn
	 */
	public Date getSubmittedOn() {
		return submittedOn;
	}

	/**
	 * @param submittedOn the submittedOn to set
	 */
	public void setSubmittedOn(Date submittedOn) {
		this.submittedOn = submittedOn;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Requests [requestId=" + requestId + ", typeOfRequest=" + typeOfRequest + ", userId=" + userId
				+ ", leadId=" + leadId + ", leaveStartDate=" + leaveStartDate + ", leaveEndDate=" + leaveEndDate
				+ ", taskId=" + taskId + ", extenstionDate=" + extenstionDate + ", comments=" + comments
				+ ", submittedOn=" + submittedOn + ", status=" + status + "]";
	}

}
