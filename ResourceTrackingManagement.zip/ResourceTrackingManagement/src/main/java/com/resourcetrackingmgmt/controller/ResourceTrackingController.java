package com.resourcetrackingmgmt.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.resourcetrackingmgmt.model.Groups;
import com.resourcetrackingmgmt.model.TaskList;
import com.resourcetrackingmgmt.model.Users;
import com.resourcetrackingmgmt.service.ResourceTrackingService;

@Controller
public class ResourceTrackingController {

	@Autowired
	ResourceTrackingService resourceTrackingService;
	
	@PostMapping(value = "/register")
	public void userRegistration(Users users) {
		resourceTrackingService.userRegistration(users);
	}
	
	@PostMapping(value = "/creategroup")
	public void createGroup(Groups groups) {
		resourceTrackingService.createGroup(groups);
	}
	
	@PostMapping(value = "/createtask")
	public void createTaskGroup(TaskList taskList) {
		taskList.setProgress("Started");
		resourceTrackingService.createTaskGroup(taskList);
	}
	
	//has to get email/UserId of user and role what admin assigned
	@GetMapping(value = "/approveuser")
	public void approveUser(Users users, String email, String role) {
		List<Users> userList = new ArrayList<Users>();
		for(Users user : userList) {
			if(user.getEmail().equals(email)) {
				resourceTrackingService.approveUser(user, role);
			}
		}
	}
	
	
	
	
}
