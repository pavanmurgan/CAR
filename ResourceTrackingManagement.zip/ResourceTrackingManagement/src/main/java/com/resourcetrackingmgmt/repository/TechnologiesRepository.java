package com.resourcetrackingmgmt.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.resourcetrackingmgmt.model.Technologies;

public interface TechnologiesRepository extends JpaRepository<Technologies, Long> {

}
