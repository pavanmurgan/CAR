package com.resourcetrackingmgmt.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.resourcetrackingmgmt.model.TempUsers;

public interface TempUsersRepository extends JpaRepository<TempUsers, Long> {

}
